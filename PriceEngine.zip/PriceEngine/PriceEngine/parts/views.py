import json
import pdb
from datetime import datetime

from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.utils import timezone
from django.utils.timezone import make_aware
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from .models import Parts

@csrf_exempt
@require_http_methods(["POST"])
def estimate_cycle_cost(request):
    response = {}
    try:
        final_price=0.0
        pdb.set_trace()
        if request.method == 'POST':
            received_json_data = json.loads(request.body)
            for item in received_json_data:
                product = item.get('product', None)
                count = item.get('count', 1)
                if product:
                    rec = Parts.objects.filter(name=product).filter(end_date__gte=datetime.now(tz=timezone.utc),
                                                                    start_date__lte=datetime.now(tz=timezone.utc)).first()
                    if rec:
                        price = rec.price
                        final_price += (float(price) * count)
                    else:
                        response['error']='product [{}] not found'.format(product)
                        response['status']= 400

                        return JsonResponse(response)
            response['final_price'] = final_price
            response['status'] = 200
            return JsonResponse(response)

    except Exception as e:
        response['error'] = "Exception [{}] occurred".format(e)
        response['status'] = 500
        return JsonResponse(response)
