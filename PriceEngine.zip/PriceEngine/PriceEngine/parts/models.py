from django.db import models
from django.db.models.functions import datetime
from django.utils import timezone


class Parts(models.Model):
    name = models.CharField(max_length=32,)
    price = models.DecimalField(max_digits=9, decimal_places=2, default=0.00)
    description = models.CharField(max_length=260)
    start_date = models.DateTimeField(default=datetime.datetime.now(tz=timezone.utc), blank=False)
    end_date = models.DateTimeField(default=datetime.datetime.now(tz=timezone.utc), blank=False)

