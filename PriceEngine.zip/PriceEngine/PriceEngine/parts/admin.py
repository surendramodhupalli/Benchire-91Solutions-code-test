from django.contrib import admin

# Register your models here.
from .models import *

class PartsAdmin(admin.ModelAdmin):
    pass

admin.site.register(Parts, PartsAdmin)