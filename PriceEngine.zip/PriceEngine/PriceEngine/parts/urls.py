from django.urls import path
from . import views

urlpatterns = [
      path('estimate_cycle_cost/', views.estimate_cycle_cost, name='estimate_cycle_cost'),
]