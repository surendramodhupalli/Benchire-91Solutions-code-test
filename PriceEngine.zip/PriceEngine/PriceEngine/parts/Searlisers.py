from rest_framework import serializers

from PriceEngine.parts.models import Brakes, Tyres, Seats, Wheels, Body, Chain, Cycle


class BrakeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Brakes
        fields = '__all__'

class TyreSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tyres
        fields = '__all__'

class SeatSerializer(serializers.ModelSerializer):
    class Meta:
        model = Seats
        fields = '__all__'


class BodySerializer(serializers.ModelSerializer):
    class Meta:
        model = Body
        fields = '__all__'


class WheelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Wheels
        fields = '__all__'


class ChainSerializer(serializers.ModelSerializer):
    class Meta:
        model = Chain
        fields = '__all__'


class CycleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cycle
        fields = '__all__'
