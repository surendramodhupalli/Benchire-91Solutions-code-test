from django.apps import AppConfig


class PartsConfig(AppConfig):
    name = 'parts'
